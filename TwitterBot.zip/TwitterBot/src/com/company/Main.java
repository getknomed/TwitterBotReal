package com.company;

import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;
import static com.company.SentimentAnalyzer.findSentiment;
import static com.company.SentimentAnalyzer.init;
import java.util.*;
import java.io.*;

public class Main {

    public static void main(String[] args) throws TwitterException {
        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setDebugEnabled(true)
                .setOAuthConsumerKey("kJ4KFCLfnO1QwbySowD4RzgTO")
                .setOAuthConsumerSecret("6o6WdTjzuX9GBKVq8ICeCiJznqmXj7QABmJxyoBwUvSII14uQC")
                .setOAuthAccessToken("1544094165360906241-TSMEsmJWgBWGuc2WvhQqEHpjaiTTX4")
                .setOAuthAccessTokenSecret("BGTrZbGjkTDRXR0iwI8clpX4xI5o6ulDLn0e5lTj9FyIJ")
                .setOAuth2AccessToken("Z002NEtMTTRES1gxQU0yNkZvWW06MTpjaQ");
        TwitterFactory tf = new TwitterFactory(cb.build());
        Twitter twitter = tf.getInstance();
        /* Query query = new Query("state");
        query.setCount(100);
        QueryResult result = twitter.search(query); */

        int num_neutral = 0;
        int num_negative = 0;
        int num_realnegative = 0;
        int num_positive = 0;
        int num_realpositive = 0;

        for (int i=0; i < 10; i++) {
            Query query = new Query("economic");
            query.setCount(100);
            QueryResult result = twitter.search(query);
            System.out.println(result.getTweets().size());

            for (int f = 0; f < result.getTweets().size(); f++) {

                String tweet = result.getTweets().get(f).getText();
                String sentiment = findSentiment(tweet);
                if (sentiment.equalsIgnoreCase("Neutral")) {
                    num_neutral++;
                } else if (sentiment.equalsIgnoreCase("Positive")) {
                    num_positive++;
                } else if (sentiment.equalsIgnoreCase("Negative")) {
                    num_negative++;
                } else if (sentiment.equalsIgnoreCase("Very Negative")) {
                    num_realnegative++;
                } else if (sentiment.equalsIgnoreCase("Very Positive")) {
                    num_realpositive++;
                }
                System.out.println("Query " + i + ", tweet " + f);

            }
        }

        System.out.println(num_neutral);
        System.out.println(num_negative);
        System.out.println(num_positive);
        System.out.println(num_realnegative);
        System.out.println(num_realpositive);
    }




}
