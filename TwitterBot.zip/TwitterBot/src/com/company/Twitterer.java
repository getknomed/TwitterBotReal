package com.company;

import twitter4j.*;
import java.io.*;
import java.util.*;


public class Twitterer {
    private Twitter twitter;
    private PrintStream consolePrint;
    private List<Status> statuses;

    public Twitterer(PrintStream console) {

    }
}
